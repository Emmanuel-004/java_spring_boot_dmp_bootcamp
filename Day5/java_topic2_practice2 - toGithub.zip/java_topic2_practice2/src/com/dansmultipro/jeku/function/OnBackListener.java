package com.dansmultipro.jeku.function;

@FunctionalInterface
public interface OnBackListener<T> {
    void onBack(T param);
}
