package com.dansmultipro.jeku.constant;

public enum ServiceType {
    RIDE, SEND, FOOD
}
