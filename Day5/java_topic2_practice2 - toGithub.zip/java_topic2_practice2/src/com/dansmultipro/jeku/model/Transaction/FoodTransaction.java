package com.dansmultipro.jeku.model.Transaction;

import com.dansmultipro.jeku.constant.ServiceType;
import com.dansmultipro.jeku.model.Cart;

import java.util.ArrayList;
import java.util.List;

public class FoodTransaction extends Transaction{
    private final String restaurantName;
    private final String to;
    private final String driverName;
    private final String driverPlate;
    private final int deliveryPrice;
    private final List<Cart> orderedFoods;

    public FoodTransaction(
            String restaurantName,
            String to,
            String driverName,
            String driverPlate,
            int foodPrice,
            int deliveryPrice,
            List<Cart> orderedFoods
    ) {
        super(ServiceType.FOOD, foodPrice + deliveryPrice);
        this.restaurantName = restaurantName;
        this.to = to;
        this.driverName = driverName;
        this.driverPlate = driverPlate;
        this.deliveryPrice = deliveryPrice;
        this.orderedFoods = new ArrayList<>(orderedFoods);
    }

    public String getRestaurantName() { return restaurantName; }
    public String getDeliveryAddress() { return to; }
    public String getDriverName() { return driverName; }
    public String getDriverNumberPlate() { return driverPlate; }
    public int getDeliveryFee() { return deliveryPrice; }
    public List<Cart> getOrderedFoods() { return orderedFoods; }
}
