package com.dansmultipro.jeku.model;

import java.util.ArrayList;
import java.util.List;

public class Restaurant {
    private String restaurantName;
    private List<Menu> restaurantMenu;

    public Restaurant(String restaurantName, List<Menu> restaurantMenu){
        this.restaurantName = restaurantName;
        this.restaurantMenu = restaurantMenu;
    }
    public String getRestaurantName() {
        return restaurantName;
    }

    public List<Menu> getRestaurantMenu() {
        return restaurantMenu;
    }
}
