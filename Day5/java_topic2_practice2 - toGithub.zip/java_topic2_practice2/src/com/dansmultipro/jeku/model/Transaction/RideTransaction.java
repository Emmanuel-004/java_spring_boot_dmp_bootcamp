package com.dansmultipro.jeku.model.Transaction;

import com.dansmultipro.jeku.constant.ServiceType;

public class RideTransaction extends Transaction {
    private String from;
    private String to;
    private String driverName;
    private String driverPlate;

    public RideTransaction(
            String from,
            String to,
            String driverName,
            String driverPlate,
            int price
    ) {
        super(ServiceType.RIDE, price);
        this.from = from;
        this.to = to;
        this.driverName = driverName;
        this.driverPlate = driverPlate;
    }

    public RideTransaction(
            String from,
            String to,
            String driverName,
            String driverPlate,
            int basePrice,
            int discount
    ) {
        super(ServiceType.RIDE, basePrice);
        this.from = from;
        this.to = to;
        this.driverName = driverName;
        this.driverPlate = driverPlate;
        setDiscount(discount);
    }

    public String getPickupLocation() { return from; }
    public String getDestination() { return to; }
    public String getDriverName() { return driverName; }
    public String getDriverPlate() { return driverPlate; }
}
