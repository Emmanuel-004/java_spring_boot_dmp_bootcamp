package com.dansmultipro.jeku.model;

public class Discount {
    private String discountCode;
    private int discountValue;

    public Discount(String discountCode, int discountValue) {
        this.discountCode = discountCode;
        this.discountValue = discountValue;
    }

    public int getDiscountValue() {
        return discountValue;
    }

    public String getDiscountCode() {
        return discountCode;
    }
}
