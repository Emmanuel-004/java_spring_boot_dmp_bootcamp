package com.dansmultipro.jeku.model.Transaction;

import com.dansmultipro.jeku.constant.ServiceType;

public class SendTransaction extends Transaction {
    private final String from;
    private final String to;
    private final String driverName;
    private final String driverPlate;
    private final String[] packageType;
    private final int packageWeight;

    public SendTransaction(
            String from,
            String to,
            String driverName,
            String driverPlate,
            String packageType,
            int packageWeight,
            int price
    ) {
        super(ServiceType.SEND, price);
        this.from = from;
        this.to = to;
        this.driverName = driverName;
        this.driverPlate = driverPlate;
        this.packageType = new String[]{packageType};
        this.packageWeight = packageWeight;
    }

    public SendTransaction(
            String from,
            String to,
            String driverName,
            String driverPlate,
            String packageType,
            int packageWeight,
            int basePrice,
            int discount
    ) {
        super(ServiceType.SEND, basePrice);
        this.from = from;
        this.to = to;
        this.driverName = driverName;
        this.driverPlate = driverPlate;
        this.packageType = new String[]{packageType};
        this.packageWeight = packageWeight;
        setDiscount(discount);
    }
    public String getPickupAddress() { return from; }
    public String getDeliveryAddress() { return to; }
    public String getDriverName() { return driverName; }
    public String getDriverPlate() { return driverPlate; }
    public String[] getPackageType() { return packageType; }
    public double getPackageWeight() { return packageWeight; }
}
