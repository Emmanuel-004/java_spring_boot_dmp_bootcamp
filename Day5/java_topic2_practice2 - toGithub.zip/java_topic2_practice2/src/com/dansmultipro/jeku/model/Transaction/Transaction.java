package com.dansmultipro.jeku.model.Transaction;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Transaction {
    private String id;
    private final Enum serviceType;
    private final Date transactionDate;
    private final int basePrice;
    private int discount;
    private int finalPrice;

    public Transaction(Enum serviceType, int finalPrice) {
        this.id = null;
        this.serviceType = serviceType;
        this.transactionDate = new Date();
        this.finalPrice = finalPrice;
        this.basePrice = finalPrice;
        this.discount = 0;
    }

    public String getId() { return id; }
    public Enum getServiceType() { return serviceType; }
    public int getDiscount() { return discount; }
    public int getFinalPrice() { return finalPrice; }

    public void setDiscount(int discount) {
        this.discount = discount;
        this.finalPrice = this.basePrice - discount;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFormattedDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        return sdf.format(transactionDate);
    }
}
