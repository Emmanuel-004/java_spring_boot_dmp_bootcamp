package com.dansmultipro.jeku.service.impl;

import com.dansmultipro.jeku.model.Discount;
import com.dansmultipro.jeku.model.Driver;
import com.dansmultipro.jeku.service.SendService;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SendServiceImpl implements SendService {

    @Override
    public Driver findDriver() {
        List<Driver> driverList = new ArrayList<>();
        driverList.add(new Driver("Budi", "B 2893 BKA"));
        driverList.add(new Driver("Arie", "B 3892 KEU"));
        driverList.add(new Driver("Joko", "B 5372 SKE"));
        driverList.add(new Driver("Ilham", "B 6327 UKF"));
        driverList.add(new Driver("Umar", "B 4217 TKE"));
        Random random = new Random();
        return driverList.get(random.nextInt(driverList.size()));
    }

    private List<Discount> getDiscount() {
        List<Discount> discountList = new ArrayList<>();
        discountList.add(new Discount("S3NDHEMAT", 7000));
        discountList.add(new Discount("ALLWAYSJ3KUSEND", 15000));
        discountList.add(new Discount("J3KUSENDAJA", 10000));

        return discountList;
    }

    @Override
    public Discount validateCode(String discountCode) {
        List<Discount> discountList = getDiscount();

        for (Discount discount : discountList) {
            if (discount.getDiscountCode().equals(discountCode)){
                return discount;
            }
        }
        return null;
    }

    @Override
    public int calculatePrice(int item, int itemWeight, String from, String to) {
        int totalPrice;
        if ((item == 2 || item == 4) && itemWeight < 1000){
            totalPrice = (from.length() * to.length() ) * itemWeight;
        } else if ((item == 1 || item == 3) && itemWeight <= 4000){
            totalPrice = (from.length() * to.length()) * itemWeight;
        } else {
            totalPrice = (from.length() * to.length()) * itemWeight + 10000;
        }
        return totalPrice;
    }

    @Override
    public int calculateDiscountPrice(int item, int itemWeight, String from, String to, String discountCode) {
        int basePrice = calculatePrice(item,itemWeight, from, to);
        if (discountCode == null) {
            return basePrice;
        }
        Discount discount = validateCode(discountCode);
        int discountValue = discount.getDiscountValue();

        return basePrice - discountValue;
    }

    @Override
    public String[] getPackageTypes() {
        return new String[]{"Barang Pecah belah", "Dokumen", "Barang Elektronik", "Obat Obatan"};
    }
}
