package com.dansmultipro.jeku.service;

import com.dansmultipro.jeku.model.*;

import java.awt.image.RescaleOp;
import java.util.List;

public interface FoodService {
    Driver findDriver();
    List<Restaurant> findRestaurant();
    public Cart findCartByMenu(List<Cart> carts, Menu menu);
    public Discount validateCode(String discountCode);
    int calculateSendPrice(String from, String to);
    int calculateFoodPrice(Cart cart);
    int calculateTotalPrice(List<Cart> carts);
}
