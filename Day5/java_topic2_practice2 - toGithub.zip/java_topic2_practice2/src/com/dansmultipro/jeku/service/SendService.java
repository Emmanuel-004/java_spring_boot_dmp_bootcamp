package com.dansmultipro.jeku.service;

import com.dansmultipro.jeku.model.Discount;
import com.dansmultipro.jeku.model.Driver;

import java.util.List;

public interface SendService {
    Driver findDriver();
    Discount validateCode(String discountCode);
    int calculatePrice(int item, int itemWeight, String from, String to);
    int calculateDiscountPrice(int item, int itemWeight, String from, String to, String discountCode);
    String[] getPackageTypes();
}
