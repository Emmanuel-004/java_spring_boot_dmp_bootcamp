package com.dansmultipro.jeku.service;

import com.dansmultipro.jeku.model.Discount;
import com.dansmultipro.jeku.model.Driver;

import java.util.List;

public interface RideService {
    Driver findDriver();
    int calculatePrice(String from, String to);
    Discount validateCode(String discountCode);
    int calculateDiscountPrice(String from, String to, String discountCode);
}
