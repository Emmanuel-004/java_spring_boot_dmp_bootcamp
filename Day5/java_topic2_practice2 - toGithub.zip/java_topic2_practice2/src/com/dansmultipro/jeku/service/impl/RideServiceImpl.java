package com.dansmultipro.jeku.service.impl;

import com.dansmultipro.jeku.model.Discount;
import com.dansmultipro.jeku.model.Driver;
import com.dansmultipro.jeku.service.RideService;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RideServiceImpl implements RideService {

    @Override
    public Driver findDriver() {
        List<Driver> driverList = new ArrayList<>();
        driverList.add(new Driver("Budi", "B 2893 BKA"));
        driverList.add(new Driver("Arie", "B 3892 KEU"));
        driverList.add(new Driver("Joko", "B 5372 SKE"));
        driverList.add(new Driver("Ilham", "B 6327 UKF"));
        driverList.add(new Driver("Umar", "B 4217 TKE"));
        Random random = new Random();
        return driverList.get(random.nextInt(driverList.size()));
    }

    private List<Discount> getDiscount() {
        List<Discount> discountList = new ArrayList<>();
        discountList.add(new Discount("J3KURIDEHEMAT", 7000));
        discountList.add(new Discount("SPSLJ3KRIDE", 10000));
        discountList.add(new Discount("J3KURIDEAJA", 12000));

        return discountList;
    }

    @Override
    public int calculatePrice(String from, String to) {
        return (from.length() * to.length()) * 1000;
    }

    @Override
    public Discount validateCode(String discountCode) {
        List<Discount> discountList = getDiscount();

        for (Discount discount : discountList) {
            if (discount.getDiscountCode().equals(discountCode)){
                return discount;
            }
        }
        return null;
    }

    @Override
    public int calculateDiscountPrice(String from, String to, String discountCode) {
        int basePrice = calculatePrice(from, to);
        if (discountCode == null) {
            return basePrice;
        }
        Discount discount = validateCode(discountCode);
        int discountValue = discount.getDiscountValue();

        return basePrice - discountValue;
    }
}
