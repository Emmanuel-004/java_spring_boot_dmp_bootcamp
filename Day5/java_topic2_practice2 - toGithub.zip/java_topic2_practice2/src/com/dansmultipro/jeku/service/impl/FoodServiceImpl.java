package com.dansmultipro.jeku.service.impl;

import com.dansmultipro.jeku.model.*;
import com.dansmultipro.jeku.service.FoodService;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class FoodServiceImpl implements FoodService {
    @Override
    public Driver findDriver() {
        List<Driver> driverList = new ArrayList<>();
        driverList.add(new Driver("Budi", "B 2893 BKA"));
        driverList.add(new Driver("Arie", "B 3892 KEU"));
        driverList.add(new Driver("Joko", "B 5372 SKE"));
        driverList.add(new Driver("Ilham", "B 6327 UKF"));
        driverList.add(new Driver("Umar", "B 4217 TKE"));
        Random random = new Random();
        return driverList.get(random.nextInt(driverList.size()));
    }

    @Override
    public List<Restaurant> findRestaurant() {
        List<Menu> pecelUenaMenus = new ArrayList<>();
        pecelUenaMenus.add(new Menu("Nasi Ayam Pecel", 22000));
        pecelUenaMenus.add(new Menu("Nasi Lele Pecel", 18000));
        pecelUenaMenus.add(new Menu("Nasi Bebek pecel", 24000));
        pecelUenaMenus.add(new Menu("Nasi Nila Pecel", 25000));
        pecelUenaMenus.add(new Menu("Nasi bawal pecel", 25000));

        Restaurant pecelUena = new Restaurant("Tenda Pecel Uena", pecelUenaMenus);

        List<Menu> masGarengMenus = new ArrayList<>();
        masGarengMenus.add(new Menu("Mie Goreng", 15000));
        masGarengMenus.add(new Menu("nasi Goreng", 17000));
        masGarengMenus.add(new Menu("Kwetiau Goreng", 16000));
        masGarengMenus.add(new Menu("Mie Rebus", 15000));
        masGarengMenus.add(new Menu("Kewtiau Rebus", 16000));

        Restaurant masGareng = new Restaurant("Nasi Goreng Mas Gareng", masGarengMenus);

        List<Menu> baksoPakMadiMenus = new ArrayList<>();
        baksoPakMadiMenus.add(new Menu("Bakso Kecil", 15000));
        baksoPakMadiMenus.add(new Menu("Bakso Urat", 17000));
        baksoPakMadiMenus.add(new Menu("Bakso Telur", 17000));
        baksoPakMadiMenus.add(new Menu("Bakso Mercon", 21000));
        baksoPakMadiMenus.add(new Menu("Bakso polos", 12000));

        Restaurant baksoPakMadi = new Restaurant("Bakso Pak Madi", baksoPakMadiMenus);

        List<Menu> sotoBoyolaliMenus = new ArrayList<>();
        sotoBoyolaliMenus.add(new Menu("Soto Ayam Campur", 15000));
        sotoBoyolaliMenus.add(new Menu("Soto Ayam (tanpa nasi)", 12000));
        sotoBoyolaliMenus.add(new Menu("Soto Ayam (nasi pisah)", 16000));
        sotoBoyolaliMenus.add(new Menu("Soto daging", 17000));
        sotoBoyolaliMenus.add(new Menu("nasi putih", 4000));

        Restaurant sotoBoyolaliBuIda = new Restaurant("Soto Boyolali Bu Ida", sotoBoyolaliMenus);

        List<Menu> masakanChineseMenus = new ArrayList<>();
        masakanChineseMenus.add(new Menu("Mie Goreng Seafood", 22000));
        masakanChineseMenus.add(new Menu("Kwetiau Goreng Seafood", 22000));
        masakanChineseMenus.add(new Menu("Sapo Tahu", 25000));
        masakanChineseMenus.add(new Menu("Fuyunghai", 20000));
        masakanChineseMenus.add(new Menu("Sapi Lada Hitam", 30000));

        Restaurant seafood37 = new Restaurant("Restoran Chinese seafood 37", masakanChineseMenus);

        List<Restaurant> restaurants = new ArrayList<>();
        restaurants.add(pecelUena);
        restaurants.add(masGareng);
        restaurants.add(baksoPakMadi);
        restaurants.add(sotoBoyolaliBuIda);
        restaurants.add(seafood37);

        return restaurants;
    }

    private List<Discount> getDiscount() {
        List<Discount> discountList = new ArrayList<>();
        discountList.add(new Discount("J3KUFOODHEMAT", 20000));
        discountList.add(new Discount("J3KUKENYANG", 15000));
        discountList.add(new Discount("J3KUFOODAJA", 10000));

        return discountList;
    }

    @Override
    public Cart findCartByMenu(List<Cart> carts, Menu menu) {
        for (Cart cart : carts) {
            if (cart.getMenu().getMenuName().equals(menu.getMenuName())) {
                return cart;
            }
        }
        return null;
    }

    @Override
    public Discount validateCode(String discountCode) {
        List<Discount> discountList = getDiscount();

        for (Discount discount : discountList) {
            if (discount.getDiscountCode().equals(discountCode)){
                return discount;
            }
        }
        return null;
    }

    @Override
    public int calculateSendPrice(String from, String to) {
        return (from.length() * to.length()) * 100;
    }

    @Override
    public int calculateFoodPrice(Cart cart) {
        return cart.getMenu().getMenuPrice() * cart.getQuantity();
    }

    @Override
    public int calculateTotalPrice(List<Cart> carts) {
        int totalPrice = 0;
        for (Cart cart : carts){
            totalPrice += calculateFoodPrice(cart);
        }
        return totalPrice;
    }

}
