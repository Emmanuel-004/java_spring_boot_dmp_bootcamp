package com.dansmultipro.jeku.view;

import com.dansmultipro.jeku.constant.ServiceType;
import com.dansmultipro.jeku.model.*;
import com.dansmultipro.jeku.model.Transaction.FoodTransaction;
import com.dansmultipro.jeku.model.Transaction.RideTransaction;
import com.dansmultipro.jeku.model.Transaction.SendTransaction;
import com.dansmultipro.jeku.model.Transaction.Transaction;
import com.dansmultipro.jeku.util.ScannerUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainView {

    private final RideView rideView;
    private final SendView sendView;
    private final FoodView foodView;
    private final TransactionView transactionView;
    private final List<Transaction> transactionsHistory;

    public MainView(RideView rideView, SendView sendView, FoodView foodView, TransactionView transactionView) {
        this.rideView = rideView;
        this.sendView = sendView;
        this.foodView = foodView;
        this.transactionView = transactionView;
        this.transactionsHistory = new ArrayList<>();
    }

    public void show() {
        System.out.println("Selamat Datang di Jeku");
        System.out.println("1. Ride");
        System.out.println("2. Send");
        System.out.println("3. Food");
        System.out.println("4. Riwayat Transaksi");
        int chosen = ScannerUtil.scanInt("Pilih layanan kami : ",1, 4);
        if (chosen == 1) {
            rideView.show((transaction) -> {
                transactionsHistory.add(transaction);
                show();
            });
        } else if (chosen == 2) {
            sendView.show(this::backToShow);
        } else if (chosen == 3) {
            foodView.show(this::backToShow);
        } else {
            showHistory();
        }
    }

    private void backToShow(Transaction transaction) {
        transactionsHistory.add(transaction);
    }
}
