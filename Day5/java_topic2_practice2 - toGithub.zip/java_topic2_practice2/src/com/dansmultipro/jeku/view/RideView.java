package com.dansmultipro.jeku.view;

import com.dansmultipro.jeku.function.OnBackListener;
import com.dansmultipro.jeku.model.Discount;
import com.dansmultipro.jeku.model.Driver;
import com.dansmultipro.jeku.model.Transaction.RideTransaction;
import com.dansmultipro.jeku.model.Transaction.Transaction;
import com.dansmultipro.jeku.service.RideService;
import com.dansmultipro.jeku.util.ScannerUtil;

import java.util.UUID;

public class RideView {

    private final RideService rideService;

    public RideView(RideService rideService) {
        this.rideService = rideService;
    }

    void show(OnBackListener<Transaction> listener){
        System.out.println("==== Jeku Ride =====");

        String from = ScannerUtil.scanString("Lokasi Anda : ");
        String to = ScannerUtil.scanString("Tujuan Anda : ");

        Discount discount = null;
        String discountCode = null;

        String useVoucher = ScannerUtil.scanString("Gunakan voucher? (y/n): ");
        if ("y".equalsIgnoreCase(useVoucher)) {
            discountCode = ScannerUtil.scanString("Kode voucher: ");
            if (discountCode != null && !discountCode.trim().isEmpty()) {
                discount = rideService.validateCode(discountCode);
                if (discount == null) {
                    System.out.println("Kode voucher tidak valid, lanjut tanpa voucher.");
                    discountCode = null;
                } else {
                    System.out.println("Voucher diterapkan: " + discount.getDiscountCode());
                }
            }
        }
        int basePrice = rideService.calculatePrice(from, to);
        int finalPrice = rideService.calculateDiscountPrice(from, to, discountCode);
        int discountAmount = basePrice - finalPrice;
        Driver getDriver = rideService.findDriver();

        showDetail(from, to, basePrice, finalPrice, discountCode, getDriver, discountAmount);

        RideTransaction rideTransaction;
        if (discount != null) {
            rideTransaction = new RideTransaction(
                    from,
                    to,
                    getDriver.getDriverName(),
                    getDriver.getDriverNumberPlate(),
                    basePrice - discountAmount,
                    discountAmount
            );
        } else {
            rideTransaction = new RideTransaction(
                    from,
                    to,
                    getDriver.getDriverName(),
                    getDriver.getDriverNumberPlate(),
                    basePrice
            );
        }

        rideTransaction.setId("JEKU-TRX" + UUID.randomUUID());

        listener.onBack(rideTransaction);
    }

    private void showDetail(String from, String to, int basePrice, int finalPrice, String discountCode, Driver getDriver, int discountAmount) {

        System.out.println("=== Detail ====");
        System.out.println("Dari : " + from);
        System.out.println("tujuan : " + to);
        System.out.println("Nama Driver : " + getDriver.getDriverName());
        System.out.println("Plat Nomor Driver : " + getDriver.getDriverNumberPlate());
        System.out.println("Harga awal : " + basePrice);
        if (discountAmount > 0) {
            System.out.println("Diskon        : Rp " + discountAmount);
            if (discountCode != null && !discountCode.isEmpty()) {
                System.out.println("Kode Voucher  : " + discountCode);
            }
        }
        System.out.println("Harga final : " + finalPrice);
        System.out.println("=== terima kasih ===");
    }
}
