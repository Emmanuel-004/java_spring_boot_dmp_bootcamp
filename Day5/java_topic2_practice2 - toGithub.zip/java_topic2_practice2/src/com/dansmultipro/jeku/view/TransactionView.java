package com.dansmultipro.jeku.view;

import com.dansmultipro.jeku.constant.ServiceType;
import com.dansmultipro.jeku.model.Cart;
import com.dansmultipro.jeku.model.Menu;
import com.dansmultipro.jeku.model.Transaction.FoodTransaction;
import com.dansmultipro.jeku.model.Transaction.RideTransaction;
import com.dansmultipro.jeku.model.Transaction.SendTransaction;
import com.dansmultipro.jeku.model.Transaction.Transaction;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TransactionView {

    public void show(List<Transaction> transactions){
        System.out.println("\n=== Transaction History ===");

        if (transactions.isEmpty()) {
            System.out.println("Belum ada transaksi.");
            return;
        }

        List<Transaction> foodTransaction = new ArrayList<>();
        List<Transaction> rideTransaction = new ArrayList<>();
        List<Transaction> sendTransaction = new ArrayList<>();

        for (Transaction t : transactions) {
            if (t.getServiceType().equals(ServiceType.FOOD)) {
                foodTransaction.add(t);
            } else if (t.getServiceType().equals(ServiceType.RIDE)) {
                rideTransaction.add(t);
            } else if (t.getServiceType().equals(ServiceType.SEND)) {
                sendTransaction.add(t);
            }
        }

        if (!rideTransaction.isEmpty()) {
            showRideTransaction(rideTransaction);
        }
        if (!sendTransaction.isEmpty()) {
            showSendTransaction(sendTransaction);
        }
        if (!foodTransaction.isEmpty()) {
            showFoodTransaction(foodTransaction);
        }
    }
    private void showRideTransaction(List<Transaction> rideTransaction) {
        System.out.println("\n=== Ride History ===");
        for (int i = 0; i < rideTransaction.size(); i++) {
            RideTransaction rt = (RideTransaction) rideTransaction.get(i);
            System.out.println(i + 1 + "." + rt.getId());
            System.out.println("Tanggal : " + rt.getFormattedDate());
            System.out.println("Dari : " + rt.getPickupLocation());
            System.out.println("Ke : " + rt.getDestination());
            System.out.println("Nama Driver : " + rt.getDriverName());
            System.out.println("Plat No Driver : " + rt.getDriverPlate());
            System.out.println("Harga normal : " + rt.getFinalPrice());
            System.out.println("Diskon : " + rt.getDiscount());
            System.out.println("Harga akhir : " + rt.getFinalPrice());
            System.out.println();
        }
    }

    private void showSendTransaction(List<Transaction> sendTransaction) {
        System.out.println("\n=== Send History ===");
        for (int i = 0; i < sendTransaction.size(); i++) {
            SendTransaction st = (SendTransaction) sendTransaction.get(i);
            System.out.println(i + 1 + "." + st.getId());
            System.out.println("Tanggal : " + st.getFormattedDate());
            System.out.println("Dari : " + st.getPickupAddress());
            System.out.println("Ke : " + st.getDeliveryAddress());
            System.out.println("Nama Driver : " + st.getDriverName());
            System.out.println("Plat No Driver : " + st.getDriverPlate());
            System.out.println("Tipe Barang : " + Arrays.toString(st.getPackageType()));
            System.out.println("berat(Gram) : " + st.getPackageWeight());
            System.out.println("Diskon : " + st.getDiscount());
            System.out.println("Harga : " + st.getFinalPrice());
            System.out.println();
        }
    }

    private void showFoodTransaction(List<Transaction> foodTransaction) {
        System.out.println("\n=== Food History ===");
        for (int i = 0; i < foodTransaction.size(); i++) {
            FoodTransaction ft = (FoodTransaction) foodTransaction.get(i);
            System.out.println(i + 1 + "." + ft.getId());
            System.out.println("Tanggal : " + ft.getFormattedDate());
            System.out.println("Dari : " + ft.getRestaurantName());
            System.out.println("Ke : " + ft.getDeliveryAddress());
            System.out.println("Nama Driver : " + ft.getDriverName());
            System.out.println("Plat No Driver : " + ft.getDriverNumberPlate());

            System.out.println("Makanan :");
            List<Cart> orderedFoods = ft.getOrderedFoods();
            for (int j = 0; j < orderedFoods.size(); j++) {
                Cart cart = orderedFoods.get(j);
                Menu menu = cart.getMenu();
                int subtotal = menu.getMenuPrice() * cart.getQuantity();
                System.out.println(j + 1 + ". " + menu.getMenuName() + " Harga = Rp." + menu.getMenuPrice() + " @" + cart.getQuantity() + " Total = Rp." + subtotal);
            }
            System.out.println("Diskon: "+ ft.getDiscount());
            System.out.println("Ongkos Kirim : " + ft.getDeliveryFee());
            System.out.println("Total Price: "+ ft.getFinalPrice());
            System.out.println();
        }
    }
}
