package com.dansmultipro.jeku.view;

import com.dansmultipro.jeku.function.OnBackListener;
import com.dansmultipro.jeku.model.Discount;
import com.dansmultipro.jeku.model.Driver;
import com.dansmultipro.jeku.model.Transaction.SendTransaction;
import com.dansmultipro.jeku.model.Transaction.Transaction;
import com.dansmultipro.jeku.service.SendService;
import com.dansmultipro.jeku.util.ScannerUtil;

import java.util.UUID;

public class SendView {

    private final SendService sendService;

    public SendView(SendService sendService){
        this.sendService = sendService;
    }

    void show(OnBackListener<Transaction> listener){
        System.out.println("==== Jeku Send =====");

        String[] packageTypes = sendService.getPackageTypes();
        for(int i = 0; i < packageTypes.length; i++) {
            System.out.println((i + 1) +". "+ packageTypes[i]);
        }
        int selectedPackageType = ScannerUtil.scanInt("Pilih jenis barang yang anda kirim : ", 1, 4) - 1;
        int itemWeight = ScannerUtil.scanInt("Masukan berat barang anda (Gram) : ");

        System.out.println("Masukan alamat lokasi dan tujuan");

        String from = ScannerUtil.scanString("Lokasi Anda : ");
        String to = ScannerUtil.scanString("Tujuan anda : ");

        Discount discount = null;
        String discountCode = null;

        String useVoucher = ScannerUtil.scanString("Gunakan voucher? (y/n): ");
        if ("y".equalsIgnoreCase(useVoucher)) {
            discountCode = ScannerUtil.scanString("Kode voucher: ");
            if (discountCode != null && !discountCode.trim().isEmpty()) {
                discount = sendService.validateCode(discountCode);
                if (discount == null) {
                    System.out.println("Kode voucher tidak valid, lanjut tanpa voucher.");
                    discountCode = null;
                } else {
                    System.out.println("Voucher diterapkan: " + discount.getDiscountCode());
                }
            }
        }

        int basePrice = sendService.calculatePrice(selectedPackageType, itemWeight, from, to);
        int finalPrice = sendService.calculateDiscountPrice(selectedPackageType, itemWeight, from, to, discountCode);

        Driver driver = sendService.findDriver();
        int discountAmount = basePrice - finalPrice;

        showDetail(packageTypes, selectedPackageType, from, to,basePrice, finalPrice, discountCode);

        SendTransaction sendTransaction;
        if (discount != null) {
            sendTransaction = new SendTransaction(
                    from,
                    to,
                    driver.getDriverName(),
                    driver.getDriverNumberPlate(),
                    packageTypes[selectedPackageType],
                    itemWeight,
                    basePrice,
                    discountAmount
            );
        } else {
            sendTransaction = new SendTransaction(
                    from,
                    to,
                    driver.getDriverName(),
                    driver.getDriverNumberPlate(),
                    packageTypes[selectedPackageType],
                    itemWeight,
                    basePrice
            );
        }
        sendTransaction.setId("JEKU-TRX" + UUID.randomUUID().toString());

        listener.onBack(sendTransaction);
    }

    private void showDetail(String[] packageTypes, int selectedPackageType, String from, String to, int basePrice, int finalPrice, String discountCode) {
        Driver getDriver = sendService.findDriver();
        int discountAmount = basePrice - finalPrice;

        System.out.println("=== Detail ====");
        System.out.println("Dari : " + from);
        System.out.println("tujuan : " + to);
        System.out.println("Nama Driver : " + getDriver.getDriverName());
        System.out.println("Plat Nomor Driver : " + getDriver.getDriverNumberPlate());
        System.out.println("Jenis Barang : " + packageTypes[selectedPackageType]);
        System.out.println("Harga awal : " + basePrice);
        if (discountAmount > 0) {
            System.out.println("Diskon        : Rp " + discountAmount);
            if (discountCode != null && !discountCode.isEmpty()) {
                System.out.println("Kode Voucher  : " + discountCode);
            }
        }
        System.out.println("Harga final : " + finalPrice);
        System.out.println("=== terima kasih ===");
    }

}
