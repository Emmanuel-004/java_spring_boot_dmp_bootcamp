package com.dansmultipro.jeku.view;

import com.dansmultipro.jeku.function.OnBackListener;
import com.dansmultipro.jeku.model.*;
import com.dansmultipro.jeku.model.Transaction.FoodTransaction;
import com.dansmultipro.jeku.model.Transaction.Transaction;
import com.dansmultipro.jeku.service.FoodService;
import com.dansmultipro.jeku.util.ScannerUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class FoodView {
    private final FoodService foodService;
    private final List<Cart> carts;
    private Restaurant selectedRestaurant;
    private OnBackListener<Transaction> currentListener;
    private Transaction foodTransaction;

    public FoodView(FoodService foodService){
        this.foodService = foodService;
        this.carts = new ArrayList<>();
    }

    void show(OnBackListener<Transaction> listener){
        this.currentListener = listener;
        System.out.println("==== Jeku Food =====");
        System.out.println("1. Lihat Restoran & Pesan");
        System.out.println("2. Lihat Keranjang");
        System.out.println("3. Kembali ke Halaman Jeku App");
        int choice = ScannerUtil.scanInt("Pilih Menu : ", 1, 3);
        if (choice == 1) {
            selectRestoAndOrder();
        } else if ( choice == 2) {
            showCartMenu();
        } else {
            show(currentListener);
        }
    }

    private void showCartMenu() {
        System.out.println("\n=== Keranjang Anda ===");
        if (carts.isEmpty()) {
            System.out.println("Keranjang anda belum terisi");
            show(currentListener);
        } else {
            displayCart();
        }

        System.out.println("\n=== Menu Keranjang ===");
        System.out.println("1. Ubah Jumlah Item");
        System.out.println("2. Hapus Item");
        System.out.println("3. Hapus Semua Item");
        System.out.println("4. Checkout");
        System.out.println("5. kembali ke Jeku Food");
        int option = ScannerUtil.scanInt("Pilih Opsi : ", 1, 5);
        if (option == 1) {
            editCartItem();
        } else if (option == 2) {
            deleteCartItem();
        } else if (option == 3) {
            deleteAllItem();
        } else if (option == 4) {
            checkout();
        } else show(currentListener);
    }

    private void selectRestoAndOrder() {
        List<Restaurant> restaurants = foodService.findRestaurant();
        for(int i = 0; i < restaurants.size(); i++) {
            System.out.println((i + 1) +". "+ restaurants.get(i).getRestaurantName());
        }

        System.out.println("Pilih restaurant : ");
        int selectedResto = ScannerUtil.scanInt("Pilih restaurant : ",0, restaurants.size()) - 1;

        selectedRestaurant = restaurants.get(selectedResto);

        selectMenu(selectedRestaurant.getRestaurantMenu(), carts);
    }

    private void displayCart() {
        int total = 0;
        for (int i = 0; i < carts.size(); i++) {
            Cart cart = carts.get(i);
            int itemPrice = foodService.calculateFoodPrice(cart);
            total += itemPrice;
            System.out.println((i + 1) + ". " + cart.getMenu().getMenuName() +
                    " x" + cart.getQuantity() +
                    " = Rp " + itemPrice);
        }
        System.out.println("====================");
        System.out.println("Total: Rp " + total);
    }

    private void editCartItem() {
        System.out.println("====================");
        int menuIndex = ScannerUtil.scanInt("Pilih menu yang anda ingin ubah : ") - 1;
        if (menuIndex >= 0 && menuIndex < carts.size()) {
            Cart cart = carts.get(menuIndex);
            int newQuantity = ScannerUtil.scanInt("Masukan jumlah yang anda inginkan : ", 1);
            cart.setQuantity(newQuantity);
            System.out.println("Jumlah " + cart.getMenu().getMenuName() +  " diperbarui menjadi " + newQuantity);
        }
        showCartMenu();
    }

    private void deleteCartItem() {
        displayCart();
        System.out.println("====================");
        int menuIndex = ScannerUtil.scanInt("Pilih menu yang anda ingin ubah : ") - 1;
        if (menuIndex >= 0 && menuIndex < carts.size()) {
            String menuName = carts.get(menuIndex).getMenu().getMenuName();
            carts.remove(menuIndex);
            System.out.println(menuName + " berhasil dihapus");
        }
        showCartMenu();
    }

    private void deleteAllItem() {
        String option = ScannerUtil.scanString("Apakah yakin ingin mengosongkan keranjang? (y/n): ");
        if("y".equalsIgnoreCase(option)) {
            carts.clear();
            System.out.println("Keranjang berhasil dikosongkan");
        } else {
            showCartMenu();
        }
    }

    private void selectMenu(List<Menu> menus, List<Cart> carts) {
        for(int i = 0; i < menus.size(); i++){
            System.out.println((i + 1) + ". "+menus.get(i).getMenuName() + " @"+ menus.get(i).getMenuPrice());
        }
        Menu selectedMenu = menus.get(ScannerUtil.scanInt("pilih menu : ") - 1);

        int foodQty = ScannerUtil.scanInt("Masukan jumlah : ");

        Cart existingCart = foodService.findCartByMenu(carts, selectedMenu);

        if(existingCart != null) {
            existingCart.setQuantity(foodQty);
            System.out.println("Quantity " + selectedMenu.getMenuName() + " ditambahkan menjadi " + existingCart.getQuantity());
        } else {
            Cart newCart = new Cart(selectedMenu, foodQty);
            carts.add(newCart);
            System.out.println("Menu " + selectedMenu.getMenuName() + " ditambahkan");
        }

        String option = ScannerUtil.scanString("Apakah ingin menambah menu? (y/n): ");
        if("y".equalsIgnoreCase(option)) {
            selectMenu(menus, carts);
        } else {
           show(currentListener);
        }
    }

    private void checkout() {
        String to = ScannerUtil.scanString("Masukan alamat anda : ");

        Driver getDriver = foodService.findDriver();
        int totalFoodPrice = foodService.calculateTotalPrice(carts);
        int sendPrice = foodService.calculateSendPrice(selectedRestaurant.getRestaurantName(), to);

        foodTransaction = new FoodTransaction(
                selectedRestaurant.getRestaurantName(),
                to,
                getDriver.getDriverName(),
                getDriver.getDriverNumberPlate(),
                totalFoodPrice,
                sendPrice,
                new ArrayList<>(carts)
        );

        foodTransaction.setId("JEKU-TRX" + UUID.randomUUID());

        showDetail(selectedRestaurant, to, carts);
        carts.clear();
        currentListener.onBack(foodTransaction);
    }

    private void showDetail(Restaurant restaurant, String to, List<Cart> carts) {
        int totalFoodPrice = foodService.calculateTotalPrice(carts);
        int sendPrice = foodService.calculateSendPrice(restaurant.getRestaurantName(), to);
        Driver getDriver = foodService.findDriver();

        System.out.println("\n=== Detail Pesanan ===");
        System.out.println("Dari : " + restaurant.getRestaurantName());
        System.out.println("Tujuan : " + to);
        System.out.println("\nMenu yang dipesan:");

        for(int i = 0; i < carts.size(); i++) {
            Cart cart = carts.get(i);
            System.out.println((i + 1) + ". " + cart.getMenu().getMenuName() +
                    " x" + cart.getQuantity() +
                    " = Rp " + foodService.calculateFoodPrice(cart));
        }

        System.out.println("\nHarga Makanan : Rp " + totalFoodPrice);
        System.out.println("Ongkos Kirim : Rp " + sendPrice);
        System.out.println("Total Bayar : Rp " + (totalFoodPrice + sendPrice));
        System.out.println("Nama Driver : " + getDriver.getDriverName());
        System.out.println("Plat Nomor Driver : " + getDriver.getDriverNumberPlate());
        System.out.println("=== Terima Kasih ===");
    }

}
