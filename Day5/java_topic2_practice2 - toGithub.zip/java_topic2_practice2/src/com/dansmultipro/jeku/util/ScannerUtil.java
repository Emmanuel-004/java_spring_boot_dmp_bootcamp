package com.dansmultipro.jeku.util;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ScannerUtil {
    public static int scanInt(String message, int min, int max) {
        Scanner scanner = new Scanner(System.in);
        System.out.print(message);
        try {
            int value = scanner.nextInt();
            if (value < min || value > max) {
                System.out.println("Input Tidak sesuai, masukan kembali");
                return scanInt(message, min, max);
            }
            return value;
        } catch (InputMismatchException e) {
            System.out.println("Input tidak valid, masukan kembali");
            return scanInt(message, min, max);
        }
    }

    public static int scanInt(String message, int min) {
        Scanner scanner = new Scanner(System.in);
        System.out.print(message);
        try {
            int value = scanner.nextInt();
            if (value < min) {
                System.out.println("Input harus lebih dari " + min);
                return scanInt(message, min);
            }
            return value;
        } catch (InputMismatchException e) {
            System.out.println("Input tidak valid, masukan kembali");
            return scanInt(message, min);
        }
    }

    public static int scanInt(String message) {
        Scanner scanner = new Scanner(System.in);
        System.out.print(message);
        try {
            return scanner.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("Input tidak valid, masukan kembali");
            return scanInt(message);
        }
    }

    public static String scanString(String message) {
        Scanner scanner = new Scanner(System.in);

        System.out.print(message);
        return scanner.nextLine();
    }
}
